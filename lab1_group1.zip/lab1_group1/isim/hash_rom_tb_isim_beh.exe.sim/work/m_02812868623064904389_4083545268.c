/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ee108/Desktop/lab1/hash_rom_tb.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {3692702878U, 0U};
static const char *ng3 = "INCORRECT HASH AT ADDR %H";
static unsigned int ng4[] = {1U, 0U};
static unsigned int ng5[] = {3694045412U, 0U};
static unsigned int ng6[] = {2U, 0U};
static unsigned int ng7[] = {895462595U, 0U};
static unsigned int ng8[] = {3U, 0U};
static unsigned int ng9[] = {2868161993U, 0U};
static unsigned int ng10[] = {4U, 0U};
static unsigned int ng11[] = {332668141U, 0U};
static unsigned int ng12[] = {5U, 0U};
static unsigned int ng13[] = {2126313640U, 0U};
static unsigned int ng14[] = {6U, 0U};
static unsigned int ng15[] = {4090354587U, 0U};
static unsigned int ng16[] = {7U, 0U};
static unsigned int ng17[] = {2571691710U, 0U};
static const char *ng18 = "All tests in test bench passed successfully!";



static void Initial_10_0(char *t0)
{
    char t8[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;

LAB0:    t1 = (t0 + 2680U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(10, ng0);

LAB4:    xsi_set_current_line(11, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(13, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 3);
    xsi_set_current_line(14, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(15, ng0);
    t2 = (t0 + 2488);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(16, ng0);
    t3 = (t0 + 1608);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1048U);
    t7 = *((char **)t6);
    memset(t8, 0, 8);
    if (*((unsigned int *)t5) != *((unsigned int *)t7))
        goto LAB7;

LAB6:    t6 = (t5 + 4);
    t9 = (t7 + 4);
    if (*((unsigned int *)t6) != *((unsigned int *)t9))
        goto LAB7;

LAB8:    t10 = (t8 + 4);
    t11 = *((unsigned int *)t10);
    t12 = (~(t11));
    t13 = *((unsigned int *)t8);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB9;

LAB10:
LAB11:    xsi_set_current_line(21, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 3);
    xsi_set_current_line(22, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(23, ng0);
    t2 = (t0 + 2488);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB13;
    goto LAB1;

LAB7:    *((unsigned int *)t8) = 1;
    goto LAB8;

LAB9:    xsi_set_current_line(16, ng0);

LAB12:    xsi_set_current_line(17, ng0);
    t16 = (t0 + 1448);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    xsi_vlogfile_write(1, 0, 0, ng3, 2, t0, (char)118, t18, 3);
    xsi_set_current_line(18, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB11;

LAB13:    xsi_set_current_line(24, ng0);
    t3 = (t0 + 1608);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1048U);
    t7 = *((char **)t6);
    memset(t8, 0, 8);
    if (*((unsigned int *)t5) != *((unsigned int *)t7))
        goto LAB15;

LAB14:    t6 = (t5 + 4);
    t9 = (t7 + 4);
    if (*((unsigned int *)t6) != *((unsigned int *)t9))
        goto LAB15;

LAB16:    t10 = (t8 + 4);
    t11 = *((unsigned int *)t10);
    t12 = (~(t11));
    t13 = *((unsigned int *)t8);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB17;

LAB18:
LAB19:    xsi_set_current_line(29, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 3);
    xsi_set_current_line(30, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(31, ng0);
    t2 = (t0 + 2488);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB21;
    goto LAB1;

LAB15:    *((unsigned int *)t8) = 1;
    goto LAB16;

LAB17:    xsi_set_current_line(24, ng0);

LAB20:    xsi_set_current_line(25, ng0);
    t16 = (t0 + 1448);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    xsi_vlogfile_write(1, 0, 0, ng3, 2, t0, (char)118, t18, 3);
    xsi_set_current_line(26, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB19;

LAB21:    xsi_set_current_line(32, ng0);
    t3 = (t0 + 1608);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1048U);
    t7 = *((char **)t6);
    memset(t8, 0, 8);
    if (*((unsigned int *)t5) != *((unsigned int *)t7))
        goto LAB23;

LAB22:    t6 = (t5 + 4);
    t9 = (t7 + 4);
    if (*((unsigned int *)t6) != *((unsigned int *)t9))
        goto LAB23;

LAB24:    t10 = (t8 + 4);
    t11 = *((unsigned int *)t10);
    t12 = (~(t11));
    t13 = *((unsigned int *)t8);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB25;

LAB26:
LAB27:    xsi_set_current_line(37, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 3);
    xsi_set_current_line(38, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(39, ng0);
    t2 = (t0 + 2488);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB29;
    goto LAB1;

LAB23:    *((unsigned int *)t8) = 1;
    goto LAB24;

LAB25:    xsi_set_current_line(32, ng0);

LAB28:    xsi_set_current_line(33, ng0);
    t16 = (t0 + 1448);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    xsi_vlogfile_write(1, 0, 0, ng3, 2, t0, (char)118, t18, 3);
    xsi_set_current_line(34, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB27;

LAB29:    xsi_set_current_line(40, ng0);
    t3 = (t0 + 1608);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1048U);
    t7 = *((char **)t6);
    memset(t8, 0, 8);
    if (*((unsigned int *)t5) != *((unsigned int *)t7))
        goto LAB31;

LAB30:    t6 = (t5 + 4);
    t9 = (t7 + 4);
    if (*((unsigned int *)t6) != *((unsigned int *)t9))
        goto LAB31;

LAB32:    t10 = (t8 + 4);
    t11 = *((unsigned int *)t10);
    t12 = (~(t11));
    t13 = *((unsigned int *)t8);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB33;

LAB34:
LAB35:    xsi_set_current_line(45, ng0);
    t2 = ((char*)((ng10)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 3);
    xsi_set_current_line(46, ng0);
    t2 = ((char*)((ng11)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(47, ng0);
    t2 = (t0 + 2488);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB37;
    goto LAB1;

LAB31:    *((unsigned int *)t8) = 1;
    goto LAB32;

LAB33:    xsi_set_current_line(40, ng0);

LAB36:    xsi_set_current_line(41, ng0);
    t16 = (t0 + 1448);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    xsi_vlogfile_write(1, 0, 0, ng3, 2, t0, (char)118, t18, 3);
    xsi_set_current_line(42, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB35;

LAB37:    xsi_set_current_line(48, ng0);
    t3 = (t0 + 1608);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1048U);
    t7 = *((char **)t6);
    memset(t8, 0, 8);
    if (*((unsigned int *)t5) != *((unsigned int *)t7))
        goto LAB39;

LAB38:    t6 = (t5 + 4);
    t9 = (t7 + 4);
    if (*((unsigned int *)t6) != *((unsigned int *)t9))
        goto LAB39;

LAB40:    t10 = (t8 + 4);
    t11 = *((unsigned int *)t10);
    t12 = (~(t11));
    t13 = *((unsigned int *)t8);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB41;

LAB42:
LAB43:    xsi_set_current_line(53, ng0);
    t2 = ((char*)((ng12)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 3);
    xsi_set_current_line(54, ng0);
    t2 = ((char*)((ng13)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(55, ng0);
    t2 = (t0 + 2488);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB45;
    goto LAB1;

LAB39:    *((unsigned int *)t8) = 1;
    goto LAB40;

LAB41:    xsi_set_current_line(48, ng0);

LAB44:    xsi_set_current_line(49, ng0);
    t16 = (t0 + 1448);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    xsi_vlogfile_write(1, 0, 0, ng3, 2, t0, (char)118, t18, 3);
    xsi_set_current_line(50, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB43;

LAB45:    xsi_set_current_line(56, ng0);
    t3 = (t0 + 1608);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1048U);
    t7 = *((char **)t6);
    memset(t8, 0, 8);
    if (*((unsigned int *)t5) != *((unsigned int *)t7))
        goto LAB47;

LAB46:    t6 = (t5 + 4);
    t9 = (t7 + 4);
    if (*((unsigned int *)t6) != *((unsigned int *)t9))
        goto LAB47;

LAB48:    t10 = (t8 + 4);
    t11 = *((unsigned int *)t10);
    t12 = (~(t11));
    t13 = *((unsigned int *)t8);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB49;

LAB50:
LAB51:    xsi_set_current_line(61, ng0);
    t2 = ((char*)((ng14)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 3);
    xsi_set_current_line(62, ng0);
    t2 = ((char*)((ng15)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(63, ng0);
    t2 = (t0 + 2488);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB53;
    goto LAB1;

LAB47:    *((unsigned int *)t8) = 1;
    goto LAB48;

LAB49:    xsi_set_current_line(56, ng0);

LAB52:    xsi_set_current_line(57, ng0);
    t16 = (t0 + 1448);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    xsi_vlogfile_write(1, 0, 0, ng3, 2, t0, (char)118, t18, 3);
    xsi_set_current_line(58, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB51;

LAB53:    xsi_set_current_line(64, ng0);
    t3 = (t0 + 1608);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1048U);
    t7 = *((char **)t6);
    memset(t8, 0, 8);
    if (*((unsigned int *)t5) != *((unsigned int *)t7))
        goto LAB55;

LAB54:    t6 = (t5 + 4);
    t9 = (t7 + 4);
    if (*((unsigned int *)t6) != *((unsigned int *)t9))
        goto LAB55;

LAB56:    t10 = (t8 + 4);
    t11 = *((unsigned int *)t10);
    t12 = (~(t11));
    t13 = *((unsigned int *)t8);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB57;

LAB58:
LAB59:    xsi_set_current_line(69, ng0);
    t2 = ((char*)((ng16)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 3);
    xsi_set_current_line(70, ng0);
    t2 = ((char*)((ng17)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(71, ng0);
    t2 = (t0 + 2488);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB61;
    goto LAB1;

LAB55:    *((unsigned int *)t8) = 1;
    goto LAB56;

LAB57:    xsi_set_current_line(64, ng0);

LAB60:    xsi_set_current_line(65, ng0);
    t16 = (t0 + 1448);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    xsi_vlogfile_write(1, 0, 0, ng3, 2, t0, (char)118, t18, 3);
    xsi_set_current_line(66, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB59;

LAB61:    xsi_set_current_line(72, ng0);
    t3 = (t0 + 1608);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1048U);
    t7 = *((char **)t6);
    memset(t8, 0, 8);
    if (*((unsigned int *)t5) != *((unsigned int *)t7))
        goto LAB63;

LAB62:    t6 = (t5 + 4);
    t9 = (t7 + 4);
    if (*((unsigned int *)t6) != *((unsigned int *)t9))
        goto LAB63;

LAB64:    t10 = (t8 + 4);
    t11 = *((unsigned int *)t10);
    t12 = (~(t11));
    t13 = *((unsigned int *)t8);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB65;

LAB66:
LAB67:    xsi_set_current_line(77, ng0);
    t2 = (t0 + 1768);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t8, 0, 8);
    t6 = (t4 + 4);
    t7 = (t5 + 4);
    t11 = *((unsigned int *)t4);
    t12 = *((unsigned int *)t5);
    t13 = (t11 ^ t12);
    t14 = *((unsigned int *)t6);
    t15 = *((unsigned int *)t7);
    t19 = (t14 ^ t15);
    t20 = (t13 | t19);
    t21 = *((unsigned int *)t6);
    t22 = *((unsigned int *)t7);
    t23 = (t21 | t22);
    t24 = (~(t23));
    t25 = (t20 & t24);
    if (t25 != 0)
        goto LAB72;

LAB69:    if (t23 != 0)
        goto LAB71;

LAB70:    *((unsigned int *)t8) = 1;

LAB72:    t10 = (t8 + 4);
    t26 = *((unsigned int *)t10);
    t27 = (~(t26));
    t28 = *((unsigned int *)t8);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB73;

LAB74:
LAB75:    goto LAB1;

LAB63:    *((unsigned int *)t8) = 1;
    goto LAB64;

LAB65:    xsi_set_current_line(72, ng0);

LAB68:    xsi_set_current_line(73, ng0);
    t16 = (t0 + 1448);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    xsi_vlogfile_write(1, 0, 0, ng3, 2, t0, (char)118, t18, 3);
    xsi_set_current_line(74, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB67;

LAB71:    t9 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB72;

LAB73:    xsi_set_current_line(77, ng0);

LAB76:    xsi_set_current_line(78, ng0);
    xsi_vlogfile_write(1, 0, 0, ng18, 1, t0);
    goto LAB75;

}


extern void work_m_02812868623064904389_4083545268_init()
{
	static char *pe[] = {(void *)Initial_10_0};
	xsi_register_didat("work_m_02812868623064904389_4083545268", "isim/hash_rom_tb_isim_beh.exe.sim/work/m_02812868623064904389_4083545268.didat");
	xsi_register_executes(pe);
}
