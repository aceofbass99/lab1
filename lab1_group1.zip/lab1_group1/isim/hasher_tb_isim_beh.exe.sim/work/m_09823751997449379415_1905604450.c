/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ee108/Desktop/lab1/hasher_tb.v";
static unsigned int ng1[] = {0U, 0U, 0U, 0U};
static unsigned int ng2[] = {0U, 0U};
static unsigned int ng3[] = {826361412U, 0U, 3749689U, 0U};
static unsigned int ng4[] = {7U, 0U};
static const char *ng5 = "%h,%h,%h";
static unsigned int ng6[] = {1398230851U, 0U, 1162630482U, 0U};
static unsigned int ng7[] = {8U, 0U};
static unsigned int ng8[] = {1380865362U, 0U, 20053U, 0U};
static unsigned int ng9[] = {6U, 0U};
static unsigned int ng10[] = {1380008777U, 0U, 21333U, 0U};
static unsigned int ng11[] = {1480935768U, 0U, 17737U, 0U};
static unsigned int ng12[] = {5U, 0U};
static unsigned int ng13[] = {860631888U, 0U, 1330532935U, 0U};
static unsigned int ng14[] = {1314009158U, 0U, 1414283607U, 0U};
static unsigned int ng15[] = {1395741249U, 0U, 16724U, 0U};
static const char *ng16 = "---";
static int ng17[] = {0, 0, 0, 0};
static int ng18[] = {1, 0};
static int ng19[] = {256, 0};



static void Initial_14_0(char *t0)
{
    char t15[8];
    char t16[16];
    char t30[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    int t14;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    unsigned int t29;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    char *t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    char *t44;
    unsigned int t45;
    char *t46;
    unsigned int t47;
    char *t48;

LAB0:    t1 = (t0 + 2520U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(14, ng0);

LAB4:    xsi_set_current_line(16, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 64);
    xsi_set_current_line(17, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    xsi_set_current_line(18, ng0);
    t2 = (t0 + 2328);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(21, ng0);
    t3 = ((char*)((ng3)));
    t4 = (t0 + 1448);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 64);
    xsi_set_current_line(22, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    xsi_set_current_line(23, ng0);
    t2 = (t0 + 2328);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    xsi_set_current_line(23, ng0);
    t3 = (t0 + 1448);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1608);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 1048U);
    t10 = *((char **)t9);
    xsi_vlogfile_write(1, 0, 0, ng5, 4, t0, (char)118, t5, 64, (char)118, t8, 4, (char)118, t10, 32);
    xsi_set_current_line(25, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 64);
    xsi_set_current_line(26, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    xsi_set_current_line(27, ng0);
    t2 = (t0 + 2328);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB7;
    goto LAB1;

LAB7:    xsi_set_current_line(27, ng0);
    t3 = (t0 + 1448);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1608);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 1048U);
    t10 = *((char **)t9);
    xsi_vlogfile_write(1, 0, 0, ng5, 4, t0, (char)118, t5, 64, (char)118, t8, 4, (char)118, t10, 32);
    xsi_set_current_line(29, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 64);
    xsi_set_current_line(30, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    xsi_set_current_line(31, ng0);
    t2 = (t0 + 2328);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB8;
    goto LAB1;

LAB8:    xsi_set_current_line(31, ng0);
    t3 = (t0 + 1448);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1608);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 1048U);
    t10 = *((char **)t9);
    xsi_vlogfile_write(1, 0, 0, ng5, 4, t0, (char)118, t5, 64, (char)118, t8, 4, (char)118, t10, 32);
    xsi_set_current_line(33, ng0);
    t2 = ((char*)((ng10)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 64);
    xsi_set_current_line(34, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    xsi_set_current_line(35, ng0);
    t2 = (t0 + 2328);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB9;
    goto LAB1;

LAB9:    xsi_set_current_line(35, ng0);
    t3 = (t0 + 1448);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1608);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 1048U);
    t10 = *((char **)t9);
    xsi_vlogfile_write(1, 0, 0, ng5, 4, t0, (char)118, t5, 64, (char)118, t8, 4, (char)118, t10, 32);
    xsi_set_current_line(37, ng0);
    t2 = ((char*)((ng11)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 64);
    xsi_set_current_line(38, ng0);
    t2 = ((char*)((ng12)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    xsi_set_current_line(39, ng0);
    t2 = (t0 + 2328);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB10;
    goto LAB1;

LAB10:    xsi_set_current_line(39, ng0);
    t3 = (t0 + 1448);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1608);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 1048U);
    t10 = *((char **)t9);
    xsi_vlogfile_write(1, 0, 0, ng5, 4, t0, (char)118, t5, 64, (char)118, t8, 4, (char)118, t10, 32);
    xsi_set_current_line(41, ng0);
    t2 = ((char*)((ng13)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 64);
    xsi_set_current_line(42, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    xsi_set_current_line(43, ng0);
    t2 = (t0 + 2328);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB11:    xsi_set_current_line(43, ng0);
    t3 = (t0 + 1448);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1608);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 1048U);
    t10 = *((char **)t9);
    xsi_vlogfile_write(1, 0, 0, ng5, 4, t0, (char)118, t5, 64, (char)118, t8, 4, (char)118, t10, 32);
    xsi_set_current_line(45, ng0);
    t2 = ((char*)((ng14)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 64);
    xsi_set_current_line(46, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    xsi_set_current_line(47, ng0);
    t2 = (t0 + 2328);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB12;
    goto LAB1;

LAB12:    xsi_set_current_line(47, ng0);
    t3 = (t0 + 1448);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1608);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 1048U);
    t10 = *((char **)t9);
    xsi_vlogfile_write(1, 0, 0, ng5, 4, t0, (char)118, t5, 64, (char)118, t8, 4, (char)118, t10, 32);
    xsi_set_current_line(49, ng0);
    t2 = ((char*)((ng15)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 64);
    xsi_set_current_line(50, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    xsi_set_current_line(51, ng0);
    t2 = (t0 + 2328);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB13;
    goto LAB1;

LAB13:    xsi_set_current_line(51, ng0);
    t3 = (t0 + 1448);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1608);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 1048U);
    t10 = *((char **)t9);
    xsi_vlogfile_write(1, 0, 0, ng5, 4, t0, (char)118, t5, 64, (char)118, t8, 4, (char)118, t10, 32);
    xsi_set_current_line(53, ng0);
    xsi_vlogfile_write(1, 0, 0, ng16, 1, t0);
    xsi_set_current_line(57, ng0);
    t2 = ((char*)((ng17)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 64);
    xsi_set_current_line(58, ng0);
    t2 = ((char*)((ng18)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    xsi_set_current_line(59, ng0);
    t2 = ((char*)((ng19)));
    t3 = (t2 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t2);
    t14 = (t13 & t12);
    t4 = (t0 + 4392);
    *((int *)t4) = t14;

LAB14:    t5 = (t0 + 4392);
    if (*((int *)t5) > 0)
        goto LAB15;

LAB16:    goto LAB1;

LAB15:    xsi_set_current_line(59, ng0);

LAB17:    xsi_set_current_line(60, ng0);
    *((int *)t15) = xsi_vlog_rtl_dist_uniform(0, 0, -2147483648, 2147483647);
    t6 = (t15 + 4);
    *((int *)t6) = 0;
    memcpy(t16, t15, 8);
    t7 = (t16 + 8);
    memset(t7, 0, 8);
    t19 = *((unsigned int *)t15);
    t20 = (t19 & 2147483648U);
    t17 = t20;
    t8 = (t15 + 4);
    t21 = *((unsigned int *)t8);
    t22 = (t21 & 2147483648U);
    t18 = t22;
    t23 = (t20 != 0);
    if (t23 == 1)
        goto LAB18;

LAB19:    t26 = (t22 != 0);
    if (t26 == 1)
        goto LAB20;

LAB21:    memcpy(t30, t16, 8);
    t31 = (t30 + 8);
    memset(t31, 0, 8);
    t34 = *((unsigned int *)t16);
    t35 = (t34 & 2147483648U);
    t32 = t35;
    t36 = (t16 + 4);
    t37 = *((unsigned int *)t36);
    t38 = (t37 & 2147483648U);
    t33 = t38;
    t39 = (t35 != 0);
    if (t39 == 1)
        goto LAB22;

LAB23:    t43 = (t38 != 0);
    if (t43 == 1)
        goto LAB24;

LAB25:    t48 = (t0 + 1448);
    xsi_vlogvar_assign_value(t48, t30, 0, 0, 64);
    xsi_set_current_line(61, ng0);
    *((int *)t15) = xsi_vlog_rtl_dist_uniform(0, 0, -2147483648, 2147483647);
    t2 = (t15 + 4);
    *((int *)t2) = 0;
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t15, 0, 0, 4);
    xsi_set_current_line(62, ng0);
    t2 = (t0 + 2328);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB26;
    goto LAB1;

LAB18:    t24 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t24 | 0U);
    t9 = (t16 + 8);
    t25 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t25 | 4294967295U);
    goto LAB19;

LAB20:    t10 = (t16 + 4);
    t27 = *((unsigned int *)t10);
    *((unsigned int *)t10) = (t27 | 0U);
    t28 = (t16 + 12);
    t29 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t29 | 4294967295U);
    goto LAB21;

LAB22:    t40 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t40 | 0U);
    t41 = (t30 + 8);
    t42 = *((unsigned int *)t41);
    *((unsigned int *)t41) = (t42 | 4294967295U);
    goto LAB23;

LAB24:    t44 = (t30 + 4);
    t45 = *((unsigned int *)t44);
    *((unsigned int *)t44) = (t45 | 0U);
    t46 = (t30 + 12);
    t47 = *((unsigned int *)t46);
    *((unsigned int *)t46) = (t47 | 4294967295U);
    goto LAB25;

LAB26:    xsi_set_current_line(62, ng0);
    t3 = (t0 + 1448);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 1608);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 1048U);
    t10 = *((char **)t9);
    xsi_vlogfile_write(1, 0, 0, ng5, 4, t0, (char)118, t5, 64, (char)118, t8, 4, (char)118, t10, 32);
    t2 = (t0 + 4392);
    t14 = *((int *)t2);
    *((int *)t2) = (t14 - 1);
    goto LAB14;

}


extern void work_m_09823751997449379415_1905604450_init()
{
	static char *pe[] = {(void *)Initial_14_0};
	xsi_register_didat("work_m_09823751997449379415_1905604450", "isim/hasher_tb_isim_beh.exe.sim/work/m_09823751997449379415_1905604450.didat");
	xsi_register_executes(pe);
}
