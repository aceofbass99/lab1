/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ee108/Desktop/lab1/hash_round_tb.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {170U, 0U};
static unsigned int ng3[] = {287454020U, 0U};
static unsigned int ng4[] = {573771793U, 0U};
static const char *ng5 = "Hash round 0 failed";
static unsigned int ng6[] = {1U, 0U};
static unsigned int ng7[] = {573775889U, 0U};
static const char *ng8 = "Hash round 1 failed";
static unsigned int ng9[] = {573784081U, 0U};
static const char *ng10 = "Hash round 2 failed";
static unsigned int ng11[] = {573770001U, 0U};
static const char *ng12 = "Hash round 3 failed";
static unsigned int ng13[] = {573772305U, 0U};
static const char *ng14 = "Hash round 4 failed";
static unsigned int ng15[] = {573824273U, 0U};
static const char *ng16 = "Hash round 5 failed";
static unsigned int ng17[] = {573815569U, 0U};
static const char *ng18 = "Hash round 6 failed";
static unsigned int ng19[] = {573798161U, 0U};
static const char *ng20 = "Hash round 7 failed";
static const char *ng21 = "--";
static unsigned int ng22[] = {1431655765U, 0U};
static unsigned int ng23[] = {1431655509U, 0U};
static unsigned int ng24[] = {1431677013U, 0U};
static unsigned int ng25[] = {1431654741U, 0U};
static unsigned int ng26[] = {1431675477U, 0U};
static unsigned int ng27[] = {1431651669U, 0U};
static unsigned int ng28[] = {1431669333U, 0U};
static unsigned int ng29[] = {1431639381U, 0U};
static unsigned int ng30[] = {1431644757U, 0U};
static const char *ng31 = "All tests in test bench passed successfully!";



static void Initial_17_0(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;

LAB0:    t1 = (t0 + 3800U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(17, ng0);

LAB4:    xsi_set_current_line(18, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(19, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2568);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(20, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2728);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(21, ng0);
    t2 = (t0 + 3608);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(22, ng0);
    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng4)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t4) != *((unsigned int *)t3))
        goto LAB7;

LAB6:    t6 = (t4 + 4);
    t7 = (t3 + 4);
    if (*((unsigned int *)t6) != *((unsigned int *)t7))
        goto LAB7;

LAB8:    t8 = (t5 + 4);
    t9 = *((unsigned int *)t8);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB9;

LAB10:
LAB11:    xsi_set_current_line(23, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng7)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t2))
        goto LAB14;

LAB13:    t4 = (t3 + 4);
    t6 = (t2 + 4);
    if (*((unsigned int *)t4) != *((unsigned int *)t6))
        goto LAB14;

LAB15:    t7 = (t5 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB16;

LAB17:
LAB18:    xsi_set_current_line(24, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng9)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t2))
        goto LAB21;

LAB20:    t4 = (t3 + 4);
    t6 = (t2 + 4);
    if (*((unsigned int *)t4) != *((unsigned int *)t6))
        goto LAB21;

LAB22:    t7 = (t5 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB23;

LAB24:
LAB25:    xsi_set_current_line(25, ng0);
    t2 = (t0 + 1528U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng11)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t2))
        goto LAB28;

LAB27:    t4 = (t3 + 4);
    t6 = (t2 + 4);
    if (*((unsigned int *)t4) != *((unsigned int *)t6))
        goto LAB28;

LAB29:    t7 = (t5 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB30;

LAB31:
LAB32:    xsi_set_current_line(26, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng13)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t2))
        goto LAB35;

LAB34:    t4 = (t3 + 4);
    t6 = (t2 + 4);
    if (*((unsigned int *)t4) != *((unsigned int *)t6))
        goto LAB35;

LAB36:    t7 = (t5 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB37;

LAB38:
LAB39:    xsi_set_current_line(27, ng0);
    t2 = (t0 + 1848U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng15)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t2))
        goto LAB42;

LAB41:    t4 = (t3 + 4);
    t6 = (t2 + 4);
    if (*((unsigned int *)t4) != *((unsigned int *)t6))
        goto LAB42;

LAB43:    t7 = (t5 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB44;

LAB45:
LAB46:    xsi_set_current_line(28, ng0);
    t2 = (t0 + 2008U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng17)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t2))
        goto LAB49;

LAB48:    t4 = (t3 + 4);
    t6 = (t2 + 4);
    if (*((unsigned int *)t4) != *((unsigned int *)t6))
        goto LAB49;

LAB50:    t7 = (t5 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB51;

LAB52:
LAB53:    xsi_set_current_line(29, ng0);
    t2 = (t0 + 2168U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng19)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t2))
        goto LAB56;

LAB55:    t4 = (t3 + 4);
    t6 = (t2 + 4);
    if (*((unsigned int *)t4) != *((unsigned int *)t6))
        goto LAB56;

LAB57:    t7 = (t5 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB58;

LAB59:
LAB60:    xsi_set_current_line(31, ng0);
    xsi_vlogfile_write(1, 0, 0, ng21, 1, t0);
    xsi_set_current_line(33, ng0);
    t2 = ((char*)((ng22)));
    t3 = (t0 + 2728);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(34, ng0);
    t2 = (t0 + 3608);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB62;
    goto LAB1;

LAB7:    *((unsigned int *)t5) = 1;
    goto LAB8;

LAB9:    xsi_set_current_line(22, ng0);

LAB12:    xsi_set_current_line(22, ng0);
    xsi_vlogfile_write(1, 0, 0, ng5, 1, t0);
    xsi_set_current_line(22, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB11;

LAB14:    *((unsigned int *)t5) = 1;
    goto LAB15;

LAB16:    xsi_set_current_line(23, ng0);

LAB19:    xsi_set_current_line(23, ng0);
    xsi_vlogfile_write(1, 0, 0, ng8, 1, t0);
    xsi_set_current_line(23, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB18;

LAB21:    *((unsigned int *)t5) = 1;
    goto LAB22;

LAB23:    xsi_set_current_line(24, ng0);

LAB26:    xsi_set_current_line(24, ng0);
    xsi_vlogfile_write(1, 0, 0, ng10, 1, t0);
    xsi_set_current_line(24, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB25;

LAB28:    *((unsigned int *)t5) = 1;
    goto LAB29;

LAB30:    xsi_set_current_line(25, ng0);

LAB33:    xsi_set_current_line(25, ng0);
    xsi_vlogfile_write(1, 0, 0, ng12, 1, t0);
    xsi_set_current_line(25, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB32;

LAB35:    *((unsigned int *)t5) = 1;
    goto LAB36;

LAB37:    xsi_set_current_line(26, ng0);

LAB40:    xsi_set_current_line(26, ng0);
    xsi_vlogfile_write(1, 0, 0, ng14, 1, t0);
    xsi_set_current_line(26, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB39;

LAB42:    *((unsigned int *)t5) = 1;
    goto LAB43;

LAB44:    xsi_set_current_line(27, ng0);

LAB47:    xsi_set_current_line(27, ng0);
    xsi_vlogfile_write(1, 0, 0, ng16, 1, t0);
    xsi_set_current_line(27, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB46;

LAB49:    *((unsigned int *)t5) = 1;
    goto LAB50;

LAB51:    xsi_set_current_line(28, ng0);

LAB54:    xsi_set_current_line(28, ng0);
    xsi_vlogfile_write(1, 0, 0, ng18, 1, t0);
    xsi_set_current_line(28, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB53;

LAB56:    *((unsigned int *)t5) = 1;
    goto LAB57;

LAB58:    xsi_set_current_line(29, ng0);

LAB61:    xsi_set_current_line(29, ng0);
    xsi_vlogfile_write(1, 0, 0, ng20, 1, t0);
    xsi_set_current_line(29, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB60;

LAB62:    xsi_set_current_line(35, ng0);
    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng23)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t4) != *((unsigned int *)t3))
        goto LAB64;

LAB63:    t6 = (t4 + 4);
    t7 = (t3 + 4);
    if (*((unsigned int *)t6) != *((unsigned int *)t7))
        goto LAB64;

LAB65:    t8 = (t5 + 4);
    t9 = *((unsigned int *)t8);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB66;

LAB67:
LAB68:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng24)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t2))
        goto LAB71;

LAB70:    t4 = (t3 + 4);
    t6 = (t2 + 4);
    if (*((unsigned int *)t4) != *((unsigned int *)t6))
        goto LAB71;

LAB72:    t7 = (t5 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB73;

LAB74:
LAB75:    xsi_set_current_line(37, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng25)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t2))
        goto LAB78;

LAB77:    t4 = (t3 + 4);
    t6 = (t2 + 4);
    if (*((unsigned int *)t4) != *((unsigned int *)t6))
        goto LAB78;

LAB79:    t7 = (t5 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB80;

LAB81:
LAB82:    xsi_set_current_line(38, ng0);
    t2 = (t0 + 1528U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng26)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t2))
        goto LAB85;

LAB84:    t4 = (t3 + 4);
    t6 = (t2 + 4);
    if (*((unsigned int *)t4) != *((unsigned int *)t6))
        goto LAB85;

LAB86:    t7 = (t5 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB87;

LAB88:
LAB89:    xsi_set_current_line(39, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng27)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t2))
        goto LAB92;

LAB91:    t4 = (t3 + 4);
    t6 = (t2 + 4);
    if (*((unsigned int *)t4) != *((unsigned int *)t6))
        goto LAB92;

LAB93:    t7 = (t5 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB94;

LAB95:
LAB96:    xsi_set_current_line(40, ng0);
    t2 = (t0 + 1848U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng28)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t2))
        goto LAB99;

LAB98:    t4 = (t3 + 4);
    t6 = (t2 + 4);
    if (*((unsigned int *)t4) != *((unsigned int *)t6))
        goto LAB99;

LAB100:    t7 = (t5 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB101;

LAB102:
LAB103:    xsi_set_current_line(41, ng0);
    t2 = (t0 + 2008U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng29)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t2))
        goto LAB106;

LAB105:    t4 = (t3 + 4);
    t6 = (t2 + 4);
    if (*((unsigned int *)t4) != *((unsigned int *)t6))
        goto LAB106;

LAB107:    t7 = (t5 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB108;

LAB109:
LAB110:    xsi_set_current_line(42, ng0);
    t2 = (t0 + 2168U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng30)));
    memset(t5, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t2))
        goto LAB113;

LAB112:    t4 = (t3 + 4);
    t6 = (t2 + 4);
    if (*((unsigned int *)t4) != *((unsigned int *)t6))
        goto LAB113;

LAB114:    t7 = (t5 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB115;

LAB116:
LAB117:    xsi_set_current_line(44, ng0);
    t2 = (t0 + 2888);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t6 = ((char*)((ng1)));
    memset(t5, 0, 8);
    t7 = (t4 + 4);
    t8 = (t6 + 4);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t6);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB122;

LAB119:    if (t18 != 0)
        goto LAB121;

LAB120:    *((unsigned int *)t5) = 1;

LAB122:    t22 = (t5 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t5);
    t26 = (t25 & t24);
    t27 = (t26 != 0);
    if (t27 > 0)
        goto LAB123;

LAB124:
LAB125:    goto LAB1;

LAB64:    *((unsigned int *)t5) = 1;
    goto LAB65;

LAB66:    xsi_set_current_line(35, ng0);

LAB69:    xsi_set_current_line(35, ng0);
    xsi_vlogfile_write(1, 0, 0, ng5, 1, t0);
    xsi_set_current_line(35, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB68;

LAB71:    *((unsigned int *)t5) = 1;
    goto LAB72;

LAB73:    xsi_set_current_line(36, ng0);

LAB76:    xsi_set_current_line(36, ng0);
    xsi_vlogfile_write(1, 0, 0, ng8, 1, t0);
    xsi_set_current_line(36, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB75;

LAB78:    *((unsigned int *)t5) = 1;
    goto LAB79;

LAB80:    xsi_set_current_line(37, ng0);

LAB83:    xsi_set_current_line(37, ng0);
    xsi_vlogfile_write(1, 0, 0, ng10, 1, t0);
    xsi_set_current_line(37, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB82;

LAB85:    *((unsigned int *)t5) = 1;
    goto LAB86;

LAB87:    xsi_set_current_line(38, ng0);

LAB90:    xsi_set_current_line(38, ng0);
    xsi_vlogfile_write(1, 0, 0, ng12, 1, t0);
    xsi_set_current_line(38, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB89;

LAB92:    *((unsigned int *)t5) = 1;
    goto LAB93;

LAB94:    xsi_set_current_line(39, ng0);

LAB97:    xsi_set_current_line(39, ng0);
    xsi_vlogfile_write(1, 0, 0, ng14, 1, t0);
    xsi_set_current_line(39, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB96;

LAB99:    *((unsigned int *)t5) = 1;
    goto LAB100;

LAB101:    xsi_set_current_line(40, ng0);

LAB104:    xsi_set_current_line(40, ng0);
    xsi_vlogfile_write(1, 0, 0, ng16, 1, t0);
    xsi_set_current_line(40, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB103;

LAB106:    *((unsigned int *)t5) = 1;
    goto LAB107;

LAB108:    xsi_set_current_line(41, ng0);

LAB111:    xsi_set_current_line(41, ng0);
    xsi_vlogfile_write(1, 0, 0, ng18, 1, t0);
    xsi_set_current_line(41, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB110;

LAB113:    *((unsigned int *)t5) = 1;
    goto LAB114;

LAB115:    xsi_set_current_line(42, ng0);

LAB118:    xsi_set_current_line(42, ng0);
    xsi_vlogfile_write(1, 0, 0, ng20, 1, t0);
    xsi_set_current_line(42, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB117;

LAB121:    t21 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB122;

LAB123:    xsi_set_current_line(44, ng0);

LAB126:    xsi_set_current_line(45, ng0);
    xsi_vlogfile_write(1, 0, 0, ng31, 1, t0);
    goto LAB125;

}


extern void work_m_10309659885645624989_2099117339_init()
{
	static char *pe[] = {(void *)Initial_17_0};
	xsi_register_didat("work_m_10309659885645624989_2099117339", "isim/hash_round_tb_isim_beh.exe.sim/work/m_10309659885645624989_2099117339.didat");
	xsi_register_executes(pe);
}
